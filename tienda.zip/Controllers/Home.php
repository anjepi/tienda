<?php
   class Home extends Controllers
   {
        public function __construct()
       {
           parent:: __construct();
       }
       public function home()
       {
           $data['page_id']= 1;
           $data['tag_page']= "Home";
           $data['page_title']= "Página principal";
           $data['page_name']= "Home";
           $data['page_content']= "    Lorem ipsum dolor sit amet consectetur adipisicing elit.
            Obcaecati qui ipsum cupiditate architecto omnis a, fuga perspiciatis quasi 
            aliquid doloremque doloribus corporis ipsam, magnam soluta ut nisi suscipit perferendis fugiat!";
           $this->views->getView($this,"home",$data);
       }

       public function insertar()
       {
           $data = $this->model->setUser("Carlos",18);
           print_r($data);
       }
   }
   
?>