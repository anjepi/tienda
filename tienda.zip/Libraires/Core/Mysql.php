<?php

  Class Mysql extends Conexion{
      
      private $conexion;
      private $strquery;
      private $arrValues;
      
      function __construct()
      {
          $this->conexion = new Conexion();
          $this->conexion = $this->conexion->conect();
      }
      //Insertar  un registro

      public function insert(string $query, array $arrValues)
      {
         $this->strquery = $query;
         $this->arrValues = $arrValues;
         $insert = $this->conexion->prepare($this->strquery);
         $resInsert = $insert->execute($this->arrValues);
         if ($resinsert) {
             $lastInsert = $this->conexion->lasInsertId();
         }else{
             $lastInsert = 0;
         }
         return $lastInsert;
      }
      //Busca un registro 

      public function select(string $query)
      {
          $this->strquery = $query;
          $result = $this->conexion->prepare($this->strquery);
          $result->execute();
          $data = $result->fetch(PDO::FETCH_ASSOC);
          return $data;
      }

      //Devuelve todos los registros
      public function slect_all(string $query)
      {
          $this->strquery = $query;
          $result = $this->conexion->prepare($this->strquery);
          $result->execute();
          $data = $result->fetchall(PDO::FETCH_ASSOC);
          return $data;
      }
      //Actualiza registros
      public function update(string $query , array $arraValues)
      {
          $this->strquery = $query;
          $this->arrValues = $arraValues;
          $update = $this->conexion->prepare($this->strquery);
          $resExecute = $update->execute($this->arrValues);
          return $resExecute;
      }
      //Eliminar registros

      public function delete(string $query)
      {
         $this->strquery = $query;
         $result = $this->conexion->prepare($this->strquery);
         $result->execute();
         return $$result;
      }
  }
?>