<?php
spl_autoload_register(function($class){
    if (file_exists("Libraires/".'Core/'.$class.".php")) {
      require_once("Libraires/".'Core/'.$class.".php");
    }
   });
?>