<?php
  const BASE_URL = "http://localhost/tienda/";
   

  //Datos de conexion a base de datos
  const DB_HOST = "localhost";
  const DB_NAME = "tienda";
  Const DB_USER = "root";
  const DB_PASSWORD = "";
  const DB_CHARSET = "charset=utf8"
?>